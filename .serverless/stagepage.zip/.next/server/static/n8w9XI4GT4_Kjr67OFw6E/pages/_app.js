module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 50);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),
/* 2 */,
/* 3 */,
/* 4 */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */
/***/ (function(module, exports) {

module.exports = require("next/link");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("next/config");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */,
/* 16 */
/***/ (function(module, exports) {

module.exports = require("react-apollo");

/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("@babel/runtime/regenerator");

/***/ }),
/* 18 */,
/* 19 */
/***/ (function(module, exports) {

module.exports = require("next-seo");

/***/ }),
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */,
/* 24 */,
/* 25 */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/AppBar");

/***/ }),
/* 26 */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Toolbar");

/***/ }),
/* 27 */,
/* 28 */
/***/ (function(module, exports) {

module.exports = require("apollo-boost");

/***/ }),
/* 29 */
/***/ (function(module, exports) {

module.exports = require("next/app");

/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = require("react-jss/lib/JssProvider");

/***/ }),
/* 31 */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CssBaseline");

/***/ }),
/* 32 */
/***/ (function(module, exports) {

module.exports = require("isomorphic-fetch");

/***/ }),
/* 33 */
/***/ (function(module, exports) {

module.exports = require("jss");

/***/ }),
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(65);


/***/ }),
/* 51 */,
/* 52 */,
/* 53 */,
/* 54 */,
/* 55 */,
/* 56 */,
/* 57 */,
/* 58 */,
/* 59 */,
/* 60 */,
/* 61 */,
/* 62 */,
/* 63 */,
/* 64 */,
/* 65 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "next/app"
var app_ = __webpack_require__(29);
var app_default = /*#__PURE__*/__webpack_require__.n(app_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "react-jss/lib/JssProvider"
var JssProvider_ = __webpack_require__(30);
var JssProvider_default = /*#__PURE__*/__webpack_require__.n(JssProvider_);

// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(1);

// EXTERNAL MODULE: external "@material-ui/core/CssBaseline"
var CssBaseline_ = __webpack_require__(31);
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_);

// EXTERNAL MODULE: external "react-apollo"
var external_react_apollo_ = __webpack_require__(16);

// EXTERNAL MODULE: external "@babel/runtime/regenerator"
var regenerator_ = __webpack_require__(17);
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator_);

// EXTERNAL MODULE: external "apollo-boost"
var external_apollo_boost_ = __webpack_require__(28);

// EXTERNAL MODULE: external "isomorphic-fetch"
var external_isomorphic_fetch_ = __webpack_require__(32);
var external_isomorphic_fetch_default = /*#__PURE__*/__webpack_require__.n(external_isomorphic_fetch_);

// EXTERNAL MODULE: external "next/config"
var config_ = __webpack_require__(9);
var config_default = /*#__PURE__*/__webpack_require__.n(config_);

// CONCATENATED MODULE: ./lib/init-apollo.js




var _getConfig = config_default()(),
    publicRuntimeConfig = _getConfig.publicRuntimeConfig;

var init_apollo_apolloClient = null; // Polyfill fetch() on the server (used by apollo-client)

if (true) {
  global.fetch = external_isomorphic_fetch_default.a;
}

var graphqlUrl = publicRuntimeConfig.GRAPHQL_URI;

function create(initialState) {
  // Check out https://github.com/zeit/next.js/pull/4611 if you want to use the AWSAppSyncClient
  return new external_apollo_boost_["ApolloClient"]({
    connectToDevTools: false,
    ssrMode: true,
    // Disables forceFetch on the server (so queries are only run once) !process.browser
    link: new external_apollo_boost_["HttpLink"]({
      uri: graphqlUrl,
      // Server URL (must be absolute)
      mode: "no-cors"
    }),
    cache: new external_apollo_boost_["InMemoryCache"]().restore(initialState || {})
  });
}

function initApollo(initialState) {
  // Make sure to create a new client for every server-side request so that data
  // isn't shared between connections (which would be bad)
  if (true) {
    return create(initialState);
  } // Reuse client on the client-side


  if (!init_apollo_apolloClient) {
    init_apollo_apolloClient = create(initialState);
  }

  return init_apollo_apolloClient;
}
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(10);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// CONCATENATED MODULE: ./lib/with-apollo-client.js


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





/* harmony default export */ var with_apollo_client = (function (App) {
  var _class, _temp;

  return _temp = _class =
  /*#__PURE__*/
  function (_React$Component) {
    _inherits(Apollo, _React$Component);

    _createClass(Apollo, null, [{
      key: "getInitialProps",
      value: function () {
        var _getInitialProps = _asyncToGenerator(
        /*#__PURE__*/
        regenerator_default.a.mark(function _callee(ctx) {
          var Component, router, appProps, apollo, apolloState;
          return regenerator_default.a.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  Component = ctx.Component, router = ctx.router;
                  appProps = {};

                  if (!App.getInitialProps) {
                    _context.next = 6;
                    break;
                  }

                  _context.next = 5;
                  return App.getInitialProps(ctx);

                case 5:
                  appProps = _context.sent;

                case 6:
                  // Run all GraphQL queries in the component tree
                  // and extract the resulting data
                  apollo = initApollo();

                  if (false) {}

                  _context.prev = 8;
                  _context.next = 11;
                  return Object(external_react_apollo_["getDataFromTree"])(external_react_default.a.createElement(App, _extends({}, appProps, {
                    Component: Component,
                    router: router,
                    apolloClient: apollo
                  })));

                case 11:
                  _context.next = 16;
                  break;

                case 13:
                  _context.prev = 13;
                  _context.t0 = _context["catch"](8);
                  // Prevent Apollo Client GraphQL errors from crashing SSR.
                  // Handle them in components via the data.error prop:
                  // https://www.apollographql.com/docs/react/api/react-apollo.html#graphql-query-data-error
                  console.error("Error while running `getDataFromTree`", _context.t0);

                case 16:
                  // getDataFromTree does not call componentWillUnmount
                  // head side effect therefore need to be cleared manually
                  head_default.a.rewind();

                case 17:
                  // Extract query data from the Apollo store
                  apolloState = apollo.cache.extract();
                  return _context.abrupt("return", _objectSpread({}, appProps, {
                    apolloState: apolloState
                  }));

                case 19:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this, [[8, 13]]);
        }));

        return function getInitialProps(_x) {
          return _getInitialProps.apply(this, arguments);
        };
      }()
    }]);

    function Apollo(props) {
      var _this;

      _classCallCheck(this, Apollo);

      _this = _possibleConstructorReturn(this, _getPrototypeOf(Apollo).call(this, props));
      _this.apolloClient = initApollo(props.apolloState);
      return _this;
    }

    _createClass(Apollo, [{
      key: "render",
      value: function render() {
        return external_react_default.a.createElement(App, _extends({}, this.props, {
          apolloClient: this.apolloClient
        }));
      }
    }]);

    return Apollo;
  }(external_react_default.a.Component), _defineProperty(_class, "displayName", "withApollo(App)"), _temp;
});
// EXTERNAL MODULE: external "next/link"
var link_ = __webpack_require__(8);
var link_default = /*#__PURE__*/__webpack_require__.n(link_);

// EXTERNAL MODULE: external "@material-ui/core/AppBar"
var AppBar_ = __webpack_require__(25);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);

// EXTERNAL MODULE: external "@material-ui/core/Toolbar"
var Toolbar_ = __webpack_require__(26);
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_);

// EXTERNAL MODULE: external "@material-ui/core/Button"
var Button_ = __webpack_require__(4);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);

// CONCATENATED MODULE: ./components/Logo.js





var styles = function styles() {
  return {
    logo: {
      textTransform: "none",
      fontWeight: 700,
      fontSize: "1.2em"
    }
  };
};

var Logo_Logo = function Logo(_ref) {
  var classes = _ref.classes;
  return external_react_default.a.createElement(link_default.a, {
    href: "/"
  }, external_react_default.a.createElement(Button_default.a, {
    color: "inherit",
    className: classes.logo
  }, "StagePage"));
};

/* harmony default export */ var components_Logo = (Object(styles_["withStyles"])(styles)(Logo_Logo));
// CONCATENATED MODULE: ./components/Header.js








var Header_styles = function styles(theme) {
  return {
    innerToolbar: {
      maxWidth: theme.breakpoints.values.lg,
      alignSelf: "center",
      width: "100%",
      justifyContent: "space-between"
    }
  };
};

var Header_Header = function Header(_ref) {
  var classes = _ref.classes;
  return external_react_default.a.createElement(AppBar_default.a, {
    postition: "static",
    color: "primary"
  }, external_react_default.a.createElement(Toolbar_default.a, {
    className: classes.innerToolbar
  }, external_react_default.a.createElement(components_Logo, null), external_react_default.a.createElement(link_default.a, {
    href: "/about"
  }, external_react_default.a.createElement(Button_default.a, {
    color: "inherit"
  }, "About"))));
};

/* harmony default export */ var components_Header = (Object(styles_["withStyles"])(Header_styles, {
  withTheme: true
})(Header_Header));
// CONCATENATED MODULE: ./components/Footer.js








var Footer_styles = function styles(theme) {
  return {
    root: {
      top: "auto",
      bottom: 0
    },
    innerToolbar: {
      maxWidth: theme.breakpoints.values.lg,
      alignSelf: "center",
      width: "100%",
      justifyContent: "space-between",
      "& a": {
        color: theme.palette.primary.main
      }
    },
    button: {
      textTransform: "none"
    }
  };
};

var Footer_Footer = function Footer(_ref) {
  var classes = _ref.classes;
  return external_react_default.a.createElement(AppBar_default.a, {
    postition: "absolute",
    color: "default",
    className: classes.root
  }, external_react_default.a.createElement(Toolbar_default.a, {
    className: classes.innerToolbar
  }, external_react_default.a.createElement("a", {
    href: "https://www.stagesource.org/",
    target: "_blank"
  }, external_react_default.a.createElement(Button_default.a, {
    color: "inherit",
    className: classes.button
  }, "StagePage by StageSource")), external_react_default.a.createElement("a", {
    href: "https://stagesource.wufoo.com/forms/ro7wwyz1mraq2z/",
    target: "_blank"
  }, external_react_default.a.createElement(Button_default.a, {
    color: "inherit",
    className: classes.button
  }, "Submit a performance")), external_react_default.a.createElement("a", {
    href: "https://www.opusaffair.com/",
    target: "_blank"
  }, external_react_default.a.createElement(Button_default.a, {
    color: "inherit",
    className: classes.button
  }, "Powered by Opus Affair"))));
};

/* harmony default export */ var components_Footer = (Object(styles_["withStyles"])(Footer_styles, {
  withTheme: true
})(Footer_Footer));
// CONCATENATED MODULE: ./components/PageLayout.js
function PageLayout_typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { PageLayout_typeof = function _typeof(obj) { return typeof obj; }; } else { PageLayout_typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return PageLayout_typeof(obj); }

function PageLayout_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function PageLayout_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function PageLayout_createClass(Constructor, protoProps, staticProps) { if (protoProps) PageLayout_defineProperties(Constructor.prototype, protoProps); if (staticProps) PageLayout_defineProperties(Constructor, staticProps); return Constructor; }

function PageLayout_possibleConstructorReturn(self, call) { if (call && (PageLayout_typeof(call) === "object" || typeof call === "function")) { return call; } return PageLayout_assertThisInitialized(self); }

function PageLayout_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function PageLayout_getPrototypeOf(o) { PageLayout_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return PageLayout_getPrototypeOf(o); }

function PageLayout_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) PageLayout_setPrototypeOf(subClass, superClass); }

function PageLayout_setPrototypeOf(o, p) { PageLayout_setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return PageLayout_setPrototypeOf(o, p); }






var PageLayout_styles = function styles(theme) {
  return {
    root: {
      minHeight: "calc(100vw+".concat(theme.spacing.unit * 0, ")"),
      marginTop: theme.spacing.unit * 8,
      marginBottom: theme.spacing.unit * 10,
      width: "100%",
      maxWidth: theme.breakpoints.values.lg,
      alignItems: "center",
      margin: "auto",
      padding: "0 ".concat(theme.spacing.unit, "px"),
      "& a:not([role='button'])": {
        color: theme.palette.secondary.main,
        "&:hover": {
          color: theme.palette.primary.main
        },
        "&:active": {
          color: theme.palette.secondary.main
        }
      }
    },
    main: {// height: "100vw"
    }
  };
};

var PageLayout_PageLayout =
/*#__PURE__*/
function (_Component) {
  PageLayout_inherits(PageLayout, _Component);

  function PageLayout() {
    PageLayout_classCallCheck(this, PageLayout);

    return PageLayout_possibleConstructorReturn(this, PageLayout_getPrototypeOf(PageLayout).apply(this, arguments));
  }

  PageLayout_createClass(PageLayout, [{
    key: "render",
    value: function render() {
      var classes = this.props.classes;
      return external_react_default.a.createElement("div", {
        className: classes.root
      }, external_react_default.a.createElement(components_Header, null), external_react_default.a.createElement("div", {
        className: classes.main
      }, this.props.children), external_react_default.a.createElement(components_Footer, null));
    }
  }]);

  return PageLayout;
}(external_react_["Component"]);

/* harmony default export */ var components_PageLayout = (Object(styles_["withStyles"])(PageLayout_styles, {
  withTheme: true
})(PageLayout_PageLayout));
// EXTERNAL MODULE: external "jss"
var external_jss_ = __webpack_require__(33);

// CONCATENATED MODULE: ./components/Theme.js

var theme = Object(styles_["createMuiTheme"])({
  palette: {
    primary: {
      main: "#434343",
      light: "#434343",
      dark: "#000000",
      contrastText: "#fff"
    },
    secondary: {
      main: "#f33f3f",
      light: "#ff766a",
      dark: "#b90017",
      contrastText: "#000"
    }
  },
  typography: {
    // Use the system font instead of the default Roboto font.
    fontFamily: ["Roboto Condensed"].join(","),
    useNextVariants: true
  }
});
/* harmony default export */ var Theme = (theme); // primary: {
//   main: "#42404d",
//   light: "#4e5763",
//   dark: "#171f2a",
//   contrastText: "#fff"
// },
// secondary: {
//   main: "#51bc9a",
//   light: "#73c9ae",
//   dark: "#38836b",
//   contrastText: "#000"
// }
// CONCATENATED MODULE: ./lib/getPageContext.js




function createPageContext() {
  return {
    theme: Theme,
    // This is needed in order to deduplicate the injection of CSS in the page.
    sheetsManager: new Map(),
    // This is needed in order to inject the critical CSS.
    sheetsRegistry: new external_jss_["SheetsRegistry"](),
    // The standard class name generator.
    generateClassName: Object(styles_["createGenerateClassName"])()
  };
}

function getPageContext() {
  // Make sure to create a new context for every server-side request so that data
  // isn't shared between connections (which would be bad).
  if (true) {
    return createPageContext();
  } // Reuse context on the client-side.


  if (!global.__INIT_MATERIAL_UI__) {
    global.__INIT_MATERIAL_UI__ = createPageContext();
  }

  return global.__INIT_MATERIAL_UI__;
}
// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(19);
var external_next_seo_default = /*#__PURE__*/__webpack_require__.n(external_next_seo_);

// CONCATENATED MODULE: ./next-seo.config.js
/* harmony default export */ var next_seo_config = ({
  title: "StagePage by StageSource",
  description: "StagePage lists performances from StageSource members—including theater artists, theater companies, and related organizations in the Greater Boston area",
  openGraph: {
    type: "website",
    // url: "https://stagepage.now.sh/",
    title: "StagePage by StageSource",
    description: "StagePage lists performances from StageSource members—including theater artists, theater companies, and related organizations in the Greater Boston area",
    // Multiple Open Graph images is only available in version `7.0.0-canary.0`+ of next (see note top of README.md)
    // images: [
    //   {
    //     url: `https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces,h_500,w_1200,z_0.3/https://opus1.imgix.net/events/generic-event-bg.jpg`,
    //     width: 1200,
    //     height: 500,
    //     alt: "StagePage"
    //   }
    // ],
    site_name: "StagePage"
  }
});
// CONCATENATED MODULE: ./pages/_app.js
function _app_typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _app_typeof = function _typeof(obj) { return typeof obj; }; } else { _app_typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _app_typeof(obj); }

function _app_extends() { _app_extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _app_extends.apply(this, arguments); }

function _app_classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _app_defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _app_createClass(Constructor, protoProps, staticProps) { if (protoProps) _app_defineProperties(Constructor.prototype, protoProps); if (staticProps) _app_defineProperties(Constructor, staticProps); return Constructor; }

function _app_possibleConstructorReturn(self, call) { if (call && (_app_typeof(call) === "object" || typeof call === "function")) { return call; } return _app_assertThisInitialized(self); }

function _app_assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _app_getPrototypeOf(o) { _app_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _app_getPrototypeOf(o); }

function _app_inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _app_setPrototypeOf(subClass, superClass); }

function _app_setPrototypeOf(o, p) { _app_setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _app_setPrototypeOf(o, p); }













var _app_CalApp =
/*#__PURE__*/
function (_App) {
  _app_inherits(CalApp, _App);

  function CalApp(props) {
    var _this;

    _app_classCallCheck(this, CalApp);

    _this = _app_possibleConstructorReturn(this, _app_getPrototypeOf(CalApp).call(this, props));
    _this.pageContext = getPageContext();
    return _this;
  }

  _app_createClass(CalApp, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      // Remove the server-side injected CSS.
      var jssStyles = document.querySelector("#jss-server-side");

      if (jssStyles && jssStyles.parentNode) {
        jssStyles.parentNode.removeChild(jssStyles);
      }
    }
  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          Component = _this$props.Component,
          pageProps = _this$props.pageProps,
          apolloClient = _this$props.apolloClient;
      return external_react_default.a.createElement(app_["Container"], null, external_react_default.a.createElement(external_react_apollo_["ApolloProvider"], {
        client: apolloClient
      }, external_react_default.a.createElement(JssProvider_default.a, {
        registry: this.pageContext.sheetsRegistry,
        generateClassName: this.pageContext.generateClassName
      }, external_react_default.a.createElement(styles_["MuiThemeProvider"], {
        theme: this.pageContext.theme,
        sheetsManager: this.pageContext.sheetsManager
      }, external_react_default.a.createElement(CssBaseline_default.a, null), external_react_default.a.createElement(components_PageLayout, null, external_react_default.a.createElement(external_next_seo_default.a, {
        config: next_seo_config
      }), external_react_default.a.createElement(Component, _app_extends({
        pageContext: this.pageContext
      }, pageProps)))))));
    }
  }]);

  return CalApp;
}(app_default.a);

/* harmony default export */ var _app = __webpack_exports__["default"] = (with_apollo_client(_app_CalApp));

/***/ })
/******/ ]);