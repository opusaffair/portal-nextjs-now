module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 56);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ 1:
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 10:
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ 16:
/***/ (function(module, exports) {

module.exports = require("react-apollo");

/***/ }),

/***/ 19:
/***/ (function(module, exports) {

module.exports = require("next-seo");

/***/ }),

/***/ 2:
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Typography");

/***/ }),

/***/ 20:
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ 23:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Error; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);


function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

var Error =
/*#__PURE__*/
function (_React$Component) {
  _inherits(Error, _React$Component);

  function Error() {
    _classCallCheck(this, Error);

    return _possibleConstructorReturn(this, _getPrototypeOf(Error).apply(this, arguments));
  }

  _createClass(Error, [{
    key: "render",
    value: function render() {
      return react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("div", null, react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement("h1", null, "Error!"), this.props.statusCode ? "An error ".concat(this.props.statusCode, " occurred on server") : "An error occurred on client");
    }
  }], [{
    key: "getInitialProps",
    value: function getInitialProps(_ref) {
      var res = _ref.res,
          err = _ref.err;
      var statusCode = res ? res.statusCode : err ? err.statusCode : null;
      return {
        statusCode: statusCode
      };
    }
  }]);

  return Error;
}(react__WEBPACK_IMPORTED_MODULE_0___default.a.Component);



/***/ }),

/***/ 24:
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Paper");

/***/ }),

/***/ 35:
/***/ (function(module, exports) {

module.exports = require("graphql-tag");

/***/ }),

/***/ 36:
/***/ (function(module, exports) {

module.exports = require("striptags");

/***/ }),

/***/ 37:
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CircularProgress");

/***/ }),

/***/ 4:
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Button");

/***/ }),

/***/ 5:
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Grid");

/***/ }),

/***/ 56:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(67);


/***/ }),

/***/ 6:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return todayPlusDays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return dateToUnixTs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return timeStampToShortDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return displayTimeDateRange; });
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7);
/* harmony import */ var luxon__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(luxon__WEBPACK_IMPORTED_MODULE_0__);

var todayPlusDays = function todayPlusDays() {
  var d = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var start = Date.now();
  var end = start + d * 60 * 60 * 24 * 1000;
  var date = new Date(end);
  var dd = date.getDate();
  var mm = date.getMonth() + 1;
  var yyyy = date.getFullYear();

  if (dd < 10) {
    dd = "0" + dd;
  }

  if (mm < 10) {
    mm = "0" + mm;
  }

  return yyyy + "-" + mm + "-" + dd;
}; //Convert a date in the format yyyy-mm-dd to a Unixtime stamp
//The 'fullDay' variable determines if the date is rounded up include the full day
//instead of cutting off at midnight

var dateToUnixTs = function dateToUnixTs(date) {
  var fullDay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var zone = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "America/New_York";
  var d = luxon__WEBPACK_IMPORTED_MODULE_0__["DateTime"].fromISO(date, {
    zone: zone
  });

  if (!d.isValid) {
    return null;
  }

  if (fullDay) {
    return parseInt(d.endOf("day").toFormat("X"));
  } else {
    return parseInt(d.startOf("day").toFormat("X"));
  }
};
var timeStampToShortDate = function timeStampToShortDate(stamp) {
  var zone = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "America/New_York";
  var d = luxon__WEBPACK_IMPORTED_MODULE_0__["DateTime"].fromSeconds(stamp);
  d.setZone(zone);
  return d.toFormat("yyyy-MM-dd");
};
var displayTimeDateRange = function displayTimeDateRange(startTS, endTS) {
  var tz = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : "America/New_York";
  if (!startTS || !endTS) return null;
  var startDate = new Date(startTS * 1000);
  var endDate = new Date(endTS * 1000);
  var display;

  if (startDate.getDate() === endDate.getDate() && startDate.getMonth() === endDate.getMonth() && startDate.getFullYear() === endDate.getFullYear()) {
    display = startDate.toLocaleDateString("en", {
      month: "long",
      day: "numeric",
      year: "numeric",
      hour: "numeric",
      minute: "numeric",
      timeZone: tz
    });
  } else if (startDate.getDate() !== endDate.getDate() && startDate.getMonth() === endDate.getMonth() && startDate.getFullYear() === endDate.getFullYear()) {
    //same month and year, different dates
    display = "".concat(startDate.toLocaleDateString("en", {
      month: "long",
      day: "numeric",
      timeZone: tz
    }), "-").concat(endDate.toLocaleDateString("en", {
      day: "numeric",
      timeZone: tz
    }), ", ").concat(endDate.toLocaleDateString("en", {
      year: "numeric",
      timeZone: tz
    }));
  } else if (startDate.getMonth() != endDate.getMonth() && startDate.getFullYear() == endDate.getFullYear()) {
    //same year, different months
    display = "".concat(startDate.toLocaleDateString("en", {
      month: "long",
      day: "numeric",
      timeZone: tz
    }), "-").concat(endDate.toLocaleDateString("en", {
      month: "long",
      day: "numeric",
      year: "numeric",
      timeZone: tz
    }));
  } else if (startDate.getMonth() != endDate.getMonth() && startDate.getFullYear() != endDate.getFullYear()) {
    //everything different
    display = "".concat(startDate.toLocaleDateString("en", {
      month: "long",
      day: "numeric",
      year: "numeric",
      timeZone: tz
    }), "-").concat(endDate.toLocaleDateString("en", {
      month: "long",
      day: "numeric",
      year: "numeric",
      timeZone: tz
    }));
  } else {
    console.log("Check the date helper.");
  }

  return display;
};

/***/ }),

/***/ 67:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(0);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(20);

// EXTERNAL MODULE: external "react-apollo"
var external_react_apollo_ = __webpack_require__(16);

// EXTERNAL MODULE: external "graphql-tag"
var external_graphql_tag_ = __webpack_require__(35);
var external_graphql_tag_default = /*#__PURE__*/__webpack_require__.n(external_graphql_tag_);

// EXTERNAL MODULE: external "@material-ui/core/Grid"
var Grid_ = __webpack_require__(5);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);

// EXTERNAL MODULE: external "@material-ui/core/Paper"
var Paper_ = __webpack_require__(24);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);

// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(1);

// EXTERNAL MODULE: external "@material-ui/core/Button"
var Button_ = __webpack_require__(4);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);

// EXTERNAL MODULE: external "@material-ui/core/Typography"
var Typography_ = __webpack_require__(2);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);

// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(19);
var external_next_seo_default = /*#__PURE__*/__webpack_require__.n(external_next_seo_);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(10);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);

// EXTERNAL MODULE: external "striptags"
var external_striptags_ = __webpack_require__(36);
var external_striptags_default = /*#__PURE__*/__webpack_require__.n(external_striptags_);

// EXTERNAL MODULE: ./pages/_error.js
var _error = __webpack_require__(23);

// EXTERNAL MODULE: ./lib/date-helpers.js
var date_helpers = __webpack_require__(6);

// EXTERNAL MODULE: external "@material-ui/core/CircularProgress"
var CircularProgress_ = __webpack_require__(37);
var CircularProgress_default = /*#__PURE__*/__webpack_require__.n(CircularProgress_);

// CONCATENATED MODULE: ./components/Loading.js



var Loading_Loading = function Loading() {
  return external_react_default.a.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      alignContent: "center",
      height: "100vw"
    }
  }, external_react_default.a.createElement(CircularProgress_default.a, null));
};

/* harmony default export */ var components_Loading = (Loading_Loading);
// CONCATENATED MODULE: ./components/EventDetails.js


function _templateObject() {
  var data = _taggedTemplateLiteral(["\n  query eventDetail($slug: String!) {\n    event(slug: $slug) {\n      title\n      image_url\n      organizer_desc\n      slug\n      start_datetime\n      end_datetime\n      ticket_link\n      org_names\n      published\n      venues {\n        opus_id\n        name\n        address\n        city\n        state\n        zip_code\n        latitude\n        longitude\n      }\n    }\n  }\n"]);

  _templateObject = function _templateObject() {
    return data;
  };

  return data;
}

function _taggedTemplateLiteral(strings, raw) { if (!raw) { raw = strings.slice(0); } return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } })); }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; var ownKeys = Object.keys(source); if (typeof Object.getOwnPropertySymbols === 'function') { ownKeys = ownKeys.concat(Object.getOwnPropertySymbols(source).filter(function (sym) { return Object.getOwnPropertyDescriptor(source, sym).enumerable; })); } ownKeys.forEach(function (key) { _defineProperty(target, key, source[key]); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















var styles = function styles(theme) {
  return {
    root: _objectSpread({}, theme.mixins.gutters(), {
      paddingTop: theme.spacing.unit * 2,
      paddingBottom: theme.spacing.unit * 2
    }),
    link: {
      color: theme.palette.primary.main,
      "&:hover": {
        color: theme.palette.secondary.main
      }
    },
    img: {
      height: "auto",
      width: "100%"
    },
    para: {
      fontFamily: theme.typography.body2.fontFamily
    },
    title: {
      fontWeight: 700,
      fontSize: "2.75em"
    },
    date: {
      fontSize: "1.8em"
    },
    opuslink: {
      marginTop: theme.spacing.unit * 10
    },
    venueTitle: {
      fontWeight: 700,
      fontSize: "1.2em",
      paddingTop: theme.spacing.unit * 2
    },
    venueAddress: {
      "& a": {
        color: theme.palette.primary.main,
        "&:hover": {
          color: theme.palette.secondary.main
        }
      }
    },
    presentedBy: {
      fontWeight: 700,
      fontSize: "1.4em"
    }
  };
};

var eventDetailQuery = external_graphql_tag_default()(_templateObject());
var eventDetailQueryVars = {
  slug: ""
};

var EventDetails_EventDetails = function EventDetails(_ref) {
  var theme = _ref.theme,
      classes = _ref.classes,
      slug = _ref.slug;
  eventDetailQueryVars.slug = slug;
  return external_react_default.a.createElement(external_react_apollo_["Query"], {
    query: eventDetailQuery,
    variables: eventDetailQueryVars
  }, function (_ref2) {
    var loading = _ref2.loading,
        error = _ref2.error,
        data = _ref2.data;
    if (error) return external_react_default.a.createElement(_error["default"], {
      error: error
    });
    if (loading) return external_react_default.a.createElement(components_Loading, null);
    var event = data.event;
    if (!event || !event.published) return external_react_default.a.createElement("div", null, "No match");
    var venues = event.venues,
        org_names = event.org_names;
    return external_react_default.a.createElement("div", null, external_react_default.a.createElement("picture", null, external_react_default.a.createElement("source", {
      media: "(min-width: ".concat(theme.breakpoints.values.lg, "px)"),
      sizes: "100vw",
      srcSet: "https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces:auto,h_500,w_1200,z_0.3/".concat(event.image_url)
    }), external_react_default.a.createElement("source", {
      media: "(min-width: ".concat(theme.breakpoints.values.md, "px)"),
      sizes: "100vw",
      srcSet: "https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces:auto,h_375,w_900,z_0.3/".concat(event.image_url)
    }), external_react_default.a.createElement("source", {
      media: "(min-width: ".concat(theme.breakpoints.values.sm, "px)"),
      sizes: "100vw",
      srcSet: "https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces:auto,h_363,w_950,z_0.3/".concat(event.image_url)
    }), external_react_default.a.createElement("img", {
      srcSet: "https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces:auto,h_200,w_548,z_0.3/".concat(event.image_url),
      className: classes.img
    })), external_react_default.a.createElement(Paper_default.a, {
      className: classes.root
    }, external_react_default.a.createElement(Typography_default.a, {
      className: classes.superTitle
    }, event.creative_supertitle), external_react_default.a.createElement(Typography_default.a, {
      component: "h1",
      variant: "h2",
      className: classes.title,
      gutterBottom: true
    }, event.title), external_react_default.a.createElement(Typography_default.a, {
      variant: "h3",
      className: classes.date
    }, Object(date_helpers["b" /* displayTimeDateRange */])(event.start_datetime, event.end_datetime)), org_names && external_react_default.a.createElement(Typography_default.a, {
      variant: "h3",
      className: classes.presentedBy
    }, "Presented by ", org_names), external_react_default.a.createElement(Grid_default.a, {
      container: true,
      spacing: 24
    }, external_react_default.a.createElement(Grid_default.a, {
      item: true,
      lg: 8,
      md: 12
    }, external_react_default.a.createElement("span", {
      className: classes.para,
      dangerouslySetInnerHTML: {
        __html: "".concat(event.organizer_desc)
      }
    })), external_react_default.a.createElement(Grid_default.a, {
      item: true,
      lg: 3,
      md: 6,
      sm: 12,
      xs: 12
    }, external_react_default.a.createElement(Button_default.a, {
      variant: "contained",
      color: "secondary",
      href: event.ticket_link,
      target: "_blank",
      fullWidth: true
    }, "Official Site"), venues && external_react_default.a.createElement(external_react_["Fragment"], null, external_react_default.a.createElement(Typography_default.a, {
      variant: "h5",
      className: classes.venueTitle
    }, "Venue", venues.length > 1 ? "s" : ""), external_react_default.a.createElement(Typography_default.a, {
      className: classes.venueAddress
    }, venues.map(function (venue) {
      return external_react_default.a.createElement(external_react_["Fragment"], {
        key: venue.opus_id
      }, venue.name, external_react_default.a.createElement("br", null), external_react_default.a.createElement("a", {
        target: "_blank",
        href: "https://www.google.com/maps/dir//(".concat(venue.latitude, ",%20").concat(venue.longitude, ")")
      }, "".concat(venue.address, " ").concat(venue.city, ", ").concat(venue.state, " ").concat(venue.zip_code)), external_react_default.a.createElement("br", null), external_react_default.a.createElement("br", null));
    }))))), external_react_default.a.createElement(Typography_default.a, {
      className: classes.opuslink
    }, external_react_default.a.createElement("a", {
      className: classes.link,
      href: "https://www.opusaffair.com/events/".concat(event.slug)
    }, "admin"))), external_react_default.a.createElement(external_next_seo_default.a, {
      config: {
        title: event.title,
        description: external_striptags_default()(event.organizer_desc),
        // images: [
        //   {
        //     url: `https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces,h_500,w_1200,z_0.3/${
        //       event.image_url
        //     }`,
        //     width: 1200,
        //     height: 500,
        //     alt: event.title
        //   }
        // ],
        openGraph: {
          type: "website",
          // url: `https://stagepage.now.sh/events/${event.slug}`,
          title: event.title,
          description: event.organizer_desc
        }
      }
    }), external_react_default.a.createElement(head_default.a, null, external_react_default.a.createElement("meta", {
      property: "og:image",
      content: "https://res.cloudinary.com/opusaffair/image/fetch/c_fill,dpr_auto,f_auto,g_faces:auto,h_500,w_1200,z_0.3/".concat(event.image_url)
    })));
  });
};

/* harmony default export */ var components_EventDetails = (Object(styles_["withStyles"])(styles, {
  withTheme: true
})(EventDetails_EventDetails));
// CONCATENATED MODULE: ./pages/events.js




var events_Events = function Events(_ref) {
  var slug = _ref.router.query.slug;
  return external_react_default.a.createElement(components_EventDetails, {
    slug: slug
  });
};

/* harmony default export */ var events = __webpack_exports__["default"] = (Object(router_["withRouter"])(events_Events));

/***/ }),

/***/ 7:
/***/ (function(module, exports) {

module.exports = require("luxon");

/***/ })

/******/ });