import Button from "@material-ui/core/Button";
import { withStyles } from "@material-ui/core/styles";
import Link from "next/link";

const styles = () => ({
  logo: {
    textTransform: "none",
    fontWeight: 700,
    fontSize: "1.2em"
  }
});
const Logo = ({ classes }) => (
  <Link href="/">
    <Button color="inherit" className={classes.logo}>
      StagePage
    </Button>
  </Link>
);

export default withStyles(styles)(Logo);
