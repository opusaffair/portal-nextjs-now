import { createInstantSearch } from "react-instantsearch-dom/server";

const { InstantSearch, findResultsState } = createInstantSearch();

export { InstantSearch, findResultsState };
