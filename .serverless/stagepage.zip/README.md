# Calendar Microsite Demo

### components > PortalVirtualMenu
update with default refinement tag

### pages > index
Determine which filters will appear with the array
const visibleTagFilters = ["Early Music", "New Work / Premiere", "Holiday"];
